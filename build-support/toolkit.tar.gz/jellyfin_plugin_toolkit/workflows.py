"""Render consumer triggers around immutable shared workflow implementations."""

import re


def render(repository, revision, catalog=None):
    if not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("Workflow generation requires an immutable toolkit revision")
    prefix = repository + "/.github/workflows/"
    validate = """name: Validate release candidate
on:
  pull_request:
  workflow_dispatch:
    inputs:
      full:
        description: Execute all checks without evidence reuse
        type: boolean
        default: true
permissions:
  contents: read
  actions: read
jobs:
  validation:
    uses: PREFIXvalidate.yml@REVISION
    with:
      full: ${{ inputs.full || false }}
"""
    safety = """name: Changed-input full safety check
on:
  schedule:
    - cron: "17 7 * * *"
  workflow_dispatch:
permissions:
  contents: read
  actions: read
jobs:
  safety:
    uses: PREFIXvalidate.yml@REVISION
    with:
      ref: ${{ github.sha }}
      scheduled: ${{ github.event_name == 'schedule' }}
      full: ${{ github.event_name == 'workflow_dispatch' }}
"""
    release = """name: Build draft release artifacts
on:
  workflow_dispatch:
    inputs:
      tag:
        description: Existing draft release tag to build or retry
        required: true
        type: string
      validated_run_id:
        description: Successful validation run whose immutable artifacts should be attached
        type: string
permissions:
  contents: write
  actions: read
  id-token: write
  attestations: write
jobs:
  release:
    uses: PREFIXrelease.yml@REVISION
    with:
      tag: ${{ inputs.tag }}
      validated_run_id: ${{ inputs.validated_run_id }}
"""
    prepare = """name: Prepare release
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: write
  actions: read
  pull-requests: write
  issues: write
  id-token: write
  attestations: write
jobs:
  prepare:
    uses: PREFIXprepare-release.yml@REVISION
    with:
      app_client_id: ${{ vars.PLUGIN_APP_CLIENT_ID }}
    secrets:
      PLUGIN_APP_PRIVATE_KEY: ${{ secrets.PLUGIN_APP_PRIVATE_KEY }}
"""
    contents = {
        "validate.yml": validate,
        "safety.yml": safety,
        "release.yml": release,
        "release-please.yml": prepare,
    }
    if catalog:
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", catalog):
            raise ValueError("Invalid catalog repository")
        contents["catalog-notify.yml"] = """name: Notify configured plugin catalog
on:
  release:
    types: [published]
  workflow_dispatch:
    inputs:
      tag:
        description: Published stable release tag to retry
        type: string
        required: true
permissions:
  contents: read
jobs:
  notify:
    if: github.event_name == 'workflow_dispatch' || (!github.event.release.draft && !github.event.release.prerelease)
    uses: PREFIXcatalog-notify.yml@REVISION
    with:
      catalog_repository: CATALOG
      tag: ${{ github.event.release.tag_name || inputs.tag }}
      app_client_id: ${{ vars.PLUGIN_APP_CLIENT_ID }}
    secrets:
      PLUGIN_APP_PRIVATE_KEY: ${{ secrets.PLUGIN_APP_PRIVATE_KEY }}
""".replace("CATALOG", catalog)
    return {
        name: text.replace("PREFIX", prefix).replace("REVISION", revision)
        for name, text in contents.items()
    }
